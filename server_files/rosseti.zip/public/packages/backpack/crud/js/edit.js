/*
*
* Backpack Crud / Edit
*
*/

jQuery(function($){

    'use strict';
});
